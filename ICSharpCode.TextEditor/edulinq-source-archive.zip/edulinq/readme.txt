This is the source repository for Edulinq - a project to reimplement
LINQ to Objects for educational purposes. The introductory blog post
to the series is here:

http://msmvps.com/blogs/jon_skeet/archive/2010/09/03/reimplementing-linq-to-objects-part-1-introduction.aspx

and all other blog posts will use the Edulinq tag on my blog:
http://msmvps.com/blogs/jon_skeet/archive/tags/Edulinq/default.aspx

The posts will also be included in the "posts" directory within this
source repository.

If you have any questions, please mail me: skeet@pobox.com


