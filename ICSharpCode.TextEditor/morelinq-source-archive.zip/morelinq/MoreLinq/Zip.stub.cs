// An implementation of Zip for sequences is included in Microsoft .NET 
// Framework starting with version 4.0 and is identical to Zip in MoreLINQ. 
// For more information on Zip, see the following reference on MSDN:
// http://msdn.microsoft.com/en-us/library/dd267698.aspx
